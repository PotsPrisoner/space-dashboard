# BioSpace Monitor — Complete Setup Guide
# Joey Bellmore · BioSpaceMonitor_WithChat

═══════════════════════════════════════════════════════════════════
 PART 1 — FIREBASE SETUP  (do this first, from any browser)
═══════════════════════════════════════════════════════════════════

Firebase is the free backend that powers the global chat board.
Every phone that installs this app shares one live message board.
Free Spark plan handles this with room to spare — no credit card needed.

STEP 1 — Create your Firebase project
  1. Go to: https://console.firebase.google.com
  2. Click "Add project"
  3. Name it: BioSpaceMonitor
  4. Disable Google Analytics if asked (not needed)
  5. Click "Create project" → wait ~30 seconds

STEP 2 — Register your Android app
  1. On the project homepage, click the Android icon (</>)
  2. Android package name: com.biospace.monitor
  3. App nickname: BioSpace Monitor
  4. Leave SHA-1 blank
  5. Click "Register app"
  6. Click "Download google-services.json"  ← SAVE THIS FILE
  7. Click through the remaining steps (Next → Next → Continue)

STEP 3 — Create the Realtime Database
  1. In the left sidebar: Build → Realtime Database
  2. Click "Create Database"
  3. Choose a region (us-central1 is fine)
  4. Select "Start in test mode"  ← allows read/write for 30 days
  5. Click "Enable"
  The database URL will look like:
    https://biospaceMonitor-default-rtdb.firebaseio.com
  (You don't need to note this — it's in google-services.json automatically)

STEP 4 — Add the Security Rules (makes chat public but prevents spam)
  1. In Realtime Database → Rules tab
  2. Replace everything with this:

    {
      "rules": {
        "biospace_chat": {
          ".read": true,
          ".write": true,
          "$msg": {
            ".validate": "newData.hasChildren(['text','nick','timestamp']) &&
                          newData.child('text').isString() &&
                          newData.child('text').val().length <= 280 &&
                          newData.child('nick').isString() &&
                          newData.child('nick').val().length <= 12"
          }
        }
      }
    }

  3. Click "Publish"
  This enforces the 280-char limit and required fields at the server level.

STEP 5 — Add google-services.json as a GitHub Secret
  (This keeps your Firebase credentials out of the public repo)
  1. Open the google-services.json file you downloaded — copy ALL the text
  2. Go to your GitHub repo → Settings → Secrets and variables → Actions
  3. Click "New repository secret"
  4. Name: GOOGLE_SERVICES_JSON
  5. Value: paste the entire contents of google-services.json
  6. Click "Add secret"

  The build workflow automatically injects this file at build time.
  Never commit the actual google-services.json to git — it's in .gitignore.


═══════════════════════════════════════════════════════════════════
 PART 2 — TERMUX SETUP  (on your Android phone)
═══════════════════════════════════════════════════════════════════

Install Termux from F-Droid (NOT the Play Store version — it's outdated):
  https://f-droid.org/packages/com.termux/

Then open Termux and run these commands in order.
Answer "y" to any questions that pop up.

── STEP 1 · Update Termux packages ──────────────────────────────

pkg update -y && pkg upgrade -y

  (This takes a few minutes the first time. Let it finish.)

── STEP 2 · Install all required tools ──────────────────────────

pkg install -y git openssh gh wget curl zip unzip

── STEP 3 · Install Java 17  (the build requires exactly JDK 17) ─

pkg install -y openjdk-17

  Verify it worked:
    java -version
  Should show: openjdk version "17.x.x"

── STEP 4 · Configure Git ────────────────────────────────────────

git config --global user.name "YourGitHubUsername"
git config --global user.email "your@email.com"
git config --global init.defaultBranch main

  Replace with your actual GitHub username and email.

── STEP 5 · Log into GitHub ──────────────────────────────────────

gh auth login

  Choose when prompted:
    → GitHub.com
    → HTTPS
    → Login with a web browser

  It shows you a one-time code and a URL.
  Open that URL in your phone browser, enter the code. Done.

── STEP 6 · Create your GitHub repo and clone it ─────────────────

  Option A — brand new repo:
    gh repo create BioSpaceMonitor --private --clone
    cd BioSpaceMonitor

  Option B — repo already exists on GitHub:
    gh repo clone YourUsername/BioSpaceMonitor
    cd BioSpaceMonitor

── STEP 7 · Copy the project files into Termux ───────────────────

  First, copy BioSpaceMonitor_WithChat.zip to your phone's Downloads
  folder (share it from Claude, Google Drive, email, whatever).

  Then in Termux:
    cp /sdcard/Download/BioSpaceMonitor_WithChat.zip .
    unzip BioSpaceMonitor_WithChat.zip

  If the files extracted into a subfolder:
    cp -r BioSpaceMonitor_WithChat/* . 2>/dev/null || true
    cp -r BioSpaceMonitor_WithChat/.[!.]* . 2>/dev/null || true
    rm -rf BioSpaceMonitor_WithChat BioSpaceMonitor_WithChat.zip

  Verify the structure looks right:
    ls
    (Should see: app/  gradle/  .github/  build.gradle.kts  etc.)

── STEP 8 · Make gradlew executable ─────────────────────────────

chmod +x gradlew

── STEP 9 · Commit and push to GitHub ───────────────────────────

git add .
git commit -m "BioSpace Monitor with Firebase chat"
git push origin main

  The push triggers the GitHub Actions build automatically.

── STEP 10 · Add your Firebase secret (if not done yet) ──────────

  Do this on github.com (see Part 1, Step 5 above).
  Without it, the build will fail at the google-services step.

── STEP 11 · Watch the build ─────────────────────────────────────

  On github.com:
    Your repo → Actions tab → "Build BioSpace Monitor APK"

  Build takes about 5–10 minutes.
  Green checkmark = success.

── STEP 12 · Download and install the APK ────────────────────────

  After build succeeds, back in Termux:

    gh run download --name BioSpaceMonitor-debug
    ls
    (You should see app-debug.apk)

    cp app-debug.apk /sdcard/Download/

  Then open your Files app → Downloads → tap app-debug.apk
  If Android asks "Allow installs from unknown sources" → Allow
  Tap Install.

  Done. Open BioSpace Monitor, tap the CHAT tab.


═══════════════════════════════════════════════════════════════════
 PART 3 — HOW THE CHAT WORKS
═══════════════════════════════════════════════════════════════════

- Everyone who installs the APK shares one global message board
- Messages are stored in Firebase Realtime Database
- They appear on all connected devices in real time (usually < 1 second)
- No accounts, no sign-in — just pick a callsign (up to 12 chars)
- Messages cap at 300 in the database; oldest are pruned automatically
- A green LIVE dot in the top right means you're connected to Firebase
- A red OFFLINE dot means no connection (messages still show cached)
- The TX button is disabled while offline so you know not to try sending
- 280 character limit enforced both in the app and at the Firebase server

This is essentially a BBS / IRC board — no DMs, no threads, no accounts.
Just a shared channel for anyone running the app.


═══════════════════════════════════════════════════════════════════
 PART 4 — UPGRADING FIREBASE FROM TEST MODE (after 30 days)
═══════════════════════════════════════════════════════════════════

Test mode expires after 30 days. Before that happens:
  1. Firebase Console → Realtime Database → Rules
  2. Replace with the validated rules from Part 1 Step 4
     (those rules are permanent — no expiry)
  3. Click Publish

That's the only ongoing maintenance required.


═══════════════════════════════════════════════════════════════════
 QUICK REFERENCE — COMMON TERMUX COMMANDS
═══════════════════════════════════════════════════════════════════

Re-enter your project folder:
  cd ~/BioSpaceMonitor   (or whatever you named it)

Push an update after editing files:
  git add .
  git commit -m "description of change"
  git push origin main

Check build status:
  gh run list --limit 5

Download latest APK after a successful build:
  gh run download --name BioSpaceMonitor-debug
  cp app-debug.apk /sdcard/Download/

Check Java version:
  java -version

Check Git config:
  git config --list

Re-authenticate with GitHub if session expires:
  gh auth login
